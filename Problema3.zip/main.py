# =====================================================
# PROBLEMA 3 - CONTROL DE INVENTARIO
# =====================================================

inventario = [
    ["A101", "Teclado", 5, 10],
    ["A102", "Mouse", 12, 10],
    ["A103", "Monitor", 3, 8],
    ["A104", "Impresora", 7, 7],
    ["A105", "USB", 1, 5]
]


def calcular_pedido(stock_actual, stock_minimo):

    if stock_actual < stock_minimo:
        return stock_minimo - stock_actual

    else:
        return 0


print("===================================")
print("   SISTEMA DE REABASTECIMIENTO")
print("===================================")


for articulo in inventario:

    codigo = articulo[0]
    nombre = articulo[1]
    stock_actual = articulo[2]
    stock_minimo = articulo[3]

    cantidad_pedir = calcular_pedido(
        stock_actual,
        stock_minimo
    )

    print("-----------------------------------")
    print("Código:", codigo)
    print("Artículo:", nombre)
    print("Stock actual:", stock_actual)
    print("Stock mínimo:", stock_minimo)
    print("Cantidad a pedir:", cantidad_pedir)


print("-----------------------------------")
